<?php

namespace Drupal\pais\Plugin\Field\FieldType;

use Drupal\Component\Utility\Random;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FieldItemBase;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\TypedData\DataDefinition;

/**
 * Plugin implementation of the 'pais_field_type' field type.
 *
 * @FieldType(
 *   id = "pais_field_type",
 *   label = @Translation("Pais field type"),
 *   description = @Translation("Un campo para el pais"),
 *   default_widget = "pais_widget_type",
 *   default_formatter = "pais_formatter_type"
 * )
 */
class PaisFieldType extends FieldItemBase {

    /**
     * {@inheritdoc}
     */
    public static function propertyDefinitions(FieldStorageDefinitionInterface $field_definition) {
        $properties['value'] = DataDefinition::create('string')
            ->setLabel(new TranslatableMarkup('País'));

        return $properties;
    }

    /**
     * {@inheritdoc}
     */
    public static function schema(FieldStorageDefinitionInterface $field_definition) {
        $schema = [
            'columns' => [
                'value' => [
                    'type' => 'varchar',
                    'length' => 2,
                    'description' => t('El nombre del país'),
                    'not null' => FALSE
                ],
            ],
        ];

        return $schema;
    }

    /**
     * {@inheritdoc}
     */
    public function isEmpty() {
        $value = $this->get('value')->getValue();
        return $value === NULL || $value === '';
    }

}
